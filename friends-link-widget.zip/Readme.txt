=== Friends Link Widget ===
Contributors: vinoth06
Tags: widget, link widget, friends link, friends url, url widget, friends widget
Requires at least: 3.0
Tested up to: 3.7.1
Stable tag: 1.0
License: GPLv2 or later

Simple method to add your friends website url to your site through widget

== Description ==
Simple method to add your friends website url to your site through widget

Through this plugin user can,

* Add the custom text as a title to display
* Add upto 5 url and name
* Open URL in new/same window
* Show/Hide Bullet style


v 1.0

* Public release

== Installation ==

1. Upload the "friends -link-widget" directory to the plugins directory.
2. Go to the plugins setting page and activate "Friends Link Widget"
3. Click Appearance --> Widget in admin dashboard
4. Add "Friends Link" to your appropriate Widget. 

== Changelog ==

= 1.0 =
* Public release

== Screenshots ==
1. Widget Selection
2. Show Friends Link
